namespace FirstApp.API.Models
{
    public class User
    {
        public int id {get;set;}
        public string name {get;set;}
        public byte[] passHash {get;set;}
        public byte[] passSalt {get;set;}
    }
}