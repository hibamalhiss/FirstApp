namespace FirstApp.API.Models
{
    public class Value
    {
        public int id {get;set;}
        public string name {get;set;}
    }
}